class Constant {
  static const double normalspace = 10.0;
  static const double normalspacecontainer = 30.0;

  static const double bottomBarHeight = 75.0;

  static const double radiusBorder = 50.0;
}
