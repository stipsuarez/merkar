class AppImages {
  static const String logoGoogle = 'assets/images/google_logo.png';
}
