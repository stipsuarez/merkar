import 'package:flutter/material.dart';
class FabMenu {
  IconData icon;
  VoidCallback  action;
  FabMenu({required this.icon, required this.action});
}